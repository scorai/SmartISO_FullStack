import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage

# Ortam değişkenlerini yükle
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Modeli başlatıyoruz (örneğin GPT-4)
llm = ChatOpenAI(openai_api_key=OPENAI_API_KEY, temperature=0.0, model_name="gpt-4o-mini")

### TEMEL BİLGİLER (Basic Information) ###
basic_system_message = SystemMessage(
    content="""You are a helpful and professional assistant whose goal is to collect basic company information.Please provide your responses directly without any role labels or prefixes. Do not prepend your answer with "Assistant:" or any similar tags.

Information you need to collect:
1. Full legal name of your company. (Example: ABC Construction Inc.)
2. Industry or field your company operates in. (Example: Manufacturing, IT Services, Healthcare, Construction, etc.)
3. Total number of employees in your organization. (Include both full-time and part-time employees; an approximate number is fine.)
Optional:
4. Head office location (city and country if possible).

Your approach:
- Always ask one question at a time.
- If the user's answer is unclear, incomplete, or if they indicate they don't know (e.g., "bilmiyorum", "sonra cevap vercem", "geç", "atla"), acknowledge this in your follow-up and record the answer as pending. For validation purposes, pending answers are to be treated as complete.
- Maintain a friendly, encouraging, and professional tone at all times."""
)
basic_initial_question = "Could you please provide the full legal name of your company? (Example: ABC Construction Inc.)"
basic_followup_template = (
    "Look at the chat history and continue asking your questions to collect the remaining information. "
    "If you want to skip a question, let the user know it's fine to do so by indicating they don't know or will answer later.\n\n"
    "Chat History:\n{chat_history}"
)
basic_decide_template = (
    "Based on the following chat history, determine if all the required basic company information has been gathered. "
    "The required information are:\n"
    "1. Full legal name of your company\n"
    "2. Industry or field your company operates in\n"
    "3. Total number of employees in your organization\n\n"
    "Note: If any required information is pending because the user indicated they don't know or will answer later, consider that as complete.\n\n"
    "If all information is collected or intentionally left pending, respond with 'complete'. Otherwise, respond with 'continue'.\n\n"
    "Chat History:\n{chat_history}"
)

### ROL BİLGİLERİ (Roles) ###
roles_system_message = SystemMessage(
    content="""You are a helpful and professional assistant whose goal is to understand the organizational structure and roles.Please provide your responses directly without any role labels or prefixes. Do not prepend your answer with "Assistant:" or any similar tags.

Information you need to collect:
1. Which of the following roles exist in your organization? Please check all that apply or specify additional roles:
   - Top Management (e.g., CEO, Managing Director)
   - Quality Manager
   - Sales Manager
   - Purchase Manager
   - Production Supervisor
   - Logistics Staff
   - Operators
   - Others (please specify)
Optional:
2. Do you have an existing organizational chart or structure? If yes, can you briefly describe it? (Example: There are three main departments—Sales, Production, and Logistics.)
3. Is your organization centralized in one location or distributed across multiple sites?

Your approach:
- Ask one question at a time.
- If the user's answer is unclear, incomplete, or if they choose to skip (e.g., "bilmiyorum", "sonra cevap vercem", "skip"), acknowledge this in your follow-up and record it as pending. For validation purposes, pending answers are treated as complete.
- Maintain a friendly, supportive, and professional tone."""
)
roles_initial_question = (
    "Please specify which of the following roles exist in your organization. Options:\n"
    "- Top Management (e.g., CEO, Managing Director)\n"
    "- Quality Manager\n"
    "- Sales Manager\n"
    "- Purchase Manager\n"
    "- Production Supervisor\n"
    "- Logistics Staff\n"
    "- Operators\n"
    "- Others (please specify)"
)
roles_followup_template = (
    "Look at the chat history and continue asking your questions to collect the remaining role information. "
    "If the user doesn't know the answer, it's acceptable to mark it as pending.\n\n"
    "Chat History:\n{chat_history}"
)
roles_decide_template = (
    "Based on the following chat history, determine if the required role information has been gathered. "
    "The required information is:\n"
    "1. Which of the following roles exist in your organization (or marked as pending if skipped).\n\n"
    "Note: If the user has explicitly skipped by indicating they don't know or will answer later, consider that as complete.\n\n"
    "If the required information is collected or intentionally left pending, respond with 'complete'. Otherwise, respond with 'continue'.\n\n"
    "Chat History:\n{chat_history}"
)

### OPERASYONEL BİLGİLER (Operational) ###
operational_system_message = SystemMessage(
    content="""You are a helpful and professional assistant whose goal is to gather detailed information about your company's core business operations and processes. Please provide your responses directly without any role labels or prefixes. Do not prepend your answer with "Assistant:" or any similar tags.

Information you need to collect:
1. After your sales and purchasing processes are completed, what are the next core operational steps within your company? (Please describe them in detail. Example: Production, quality control, packaging, delivery, etc.)
2. Does your company primarily provide physical products, services, or both? (Please specify: Products, Services, or Both.)
3. Which of the following processes apply to your business operations? If yes, please provide a brief description for each:
   - Raw material procurement
   - Storage and inventory management
   - Production or assembly processes
   - Quality control and inspections
   - Packaging
   - Logistics and delivery
   - After-sales support
   - Service planning and scheduling
   - Resource allocation
   - Project management
   - Customer support after service delivery
4. Does your company perform any product or service design and development activities? If yes, please specify what you develop. (Example: We design custom machinery, develop mobile applications, or create architectural plans.)
Optional:
5. Do you have processes for risk management (ISO 9001), hazard identification (ISO 45001), or environmental aspect assessment (ISO 14001)? If yes, please briefly describe them.

Your approach:
- Ask one question at a time.
- If the user's answer is unclear, incomplete, or if they choose to skip (e.g., "bilmiyorum", "sonra cevap vercem", "skip"), acknowledge this in your follow-up and record it as pending. For validation purposes, pending answers are treated as complete.
- Maintain a friendly, supportive, and professional tone."""
)
operational_initial_question = (
    "Could you describe the core operational steps within your company after your sales and purchasing processes are completed? "
    "(Example: Production, quality control, packaging, delivery, etc.)"
)
operational_followup_template = (
    "Please continue asking your questions to collect the remaining operational process information. "
    "If the user doesn't know the answer, it's acceptable to mark it as pending.\n\n"
    "Chat History:\n{chat_history}"
)
operational_decide_template = (
    "Based on the following chat history, determine if all the required operational process information has been gathered. "
    "The required information are:\n"
    "1. The core operational steps after sales and purchasing processes\n"
    "2. Whether the company provides physical products, services, or both\n"
    "3. A brief description of which of the listed processes apply to the business operations\n"
    "4. Whether the company performs product/service design and development activities and if yes, what is developed\n\n"
    "Note: If any information is pending because the user chose to skip, consider that as complete.\n\n"
    "If all required information is collected or intentionally left pending, respond with 'complete'. Otherwise, respond with 'continue'.\n\n"
    "Chat History:\n{chat_history}"
)

### ÜRETİM (Production) ###
production_system_message = SystemMessage(
    content="""You are a helpful and professional assistant whose goal is to collect detailed information about your organization's production activities and measurement/calibration processes. Please provide your responses directly without any role labels or prefixes. Do not prepend your answer with "Assistant:" or any similar tags.

Information you need to collect:
1. Does your organization perform any production activities? If yes, please briefly describe the type of production. (Example: Manufacturing medical devices, assembling machinery, printing services.)
2. Could you outline the key stages of your production process? (Example: Production preparation, assembly, quality inspection, packaging.)
3. Do you use any measurement or testing equipment in your production activities? (If yes, please continue to the next question.)
4. Is the measurement and testing equipment regularly calibrated? If yes, please specify the types of equipment used. (Example: Scales, measuring tapes, electronic testing devices, pressure gauges.)
Optional:
5. Who performs the calibration? (Example: Your internal quality department or an external accredited laboratory.)

Your approach:
- Ask one question at a time.
- If the user's answer is unclear, incomplete, or if they choose to skip (e.g., "bilmiyorum", "sonra cevap vercem", "skip"), acknowledge this in your follow-up and record it as pending. For validation purposes, pending answers are treated as complete.
- Maintain a friendly, supportive, and professional tone."""
)
production_initial_question = (
    "Does your organization perform any production activities? If yes, please briefly describe the type of production. "
    "(Example: Manufacturing medical devices, assembling machinery, printing services.)"
)
production_followup_template = (
    "Please continue asking your questions to collect the remaining production and calibration information. "
    "If the user doesn't know the answer, it's acceptable to mark it as pending.\n\n"
    "Chat History:\n{chat_history}"
)
production_decide_template = (
    "Based on the following chat history, determine if all the required production and calibration information has been gathered. "
    "The required information are:\n"
    "1. Description of production activities\n"
    "2. Key stages of the production process\n"
    "3. Use of measurement or testing equipment in production\n"
    "4. Information on whether the equipment is regularly calibrated and types specified\n\n"
    "Note: If any information is pending because the user chose to skip, consider that as complete.\n\n"
    "If all required information is collected or intentionally left pending, respond with 'complete'. Otherwise, respond with 'continue'.\n\n"
    "Chat History:\n{chat_history}"
)

def get_bot_response(message: str, history: list = []):
    """
    Gelen mesaj ve sohbet geçmişine göre sonraki soruyu belirler.
    Aşamalar:
      1. Temel bilgilerin (basic) toplanması
      2. Rol bilgilerinin (roles) toplanması
      3. Operasyonel bilgilerin (operational) toplanması
      4. Üretim bilgileri (production) toplanması

    Her aşamada, ilgili decide template ile bilgilerin tamamlanıp tamamlanmadığı kontrol edilir.
    """
    # Eğer history boşsa, temel ilk soruyu döndür
    if not history:
        return basic_initial_question

    # Frontend formatındaki history'yi LangChain formatına dönüştürelim
    converted_history = []
    for msg in history:
        role = "user" if msg.get("isUser") else "assistant"
        converted_history.append({"role": role, "content": msg.get("text", "")})
    # Yeni gelen kullanıcı mesajını ekleyelim
    converted_history.append({"role": "user", "content": message})
    formatted_history = "\n".join(f"{m['role'].capitalize()}: {m['content']}" for m in converted_history)

    # --- 1. Temel Bilgi Kontrolü ---
    basic_decide_prompt = basic_decide_template.format(chat_history=formatted_history)
    basic_decision_response = llm([basic_system_message, HumanMessage(content=basic_decide_prompt)])
    basic_decision_text = basic_decision_response.content.strip().lower()

    if "complete" not in basic_decision_text:
        # Temel bilgiler tamamlanmamışsa, temel followup kullan
        followup_prompt = basic_followup_template.format(chat_history=formatted_history)
        response = llm([basic_system_message, HumanMessage(content=followup_prompt)])
        return response.content

    # --- 2. Rol Bilgisi Kontrolü ---
    # Rol aşamasının başlayıp başlamadığını kontrol edelim (örneğin, rollere ilişkin ilk mesajın gönderilip gönderilmediğini)
    roles_started = any((not msg["isUser"]) and (roles_initial_question in msg["text"]) for msg in history)
    roles_decide_prompt = roles_decide_template.format(chat_history=formatted_history)
    roles_decision_response = llm([roles_system_message, HumanMessage(content=roles_decide_prompt)])
    roles_decision_text = roles_decision_response.content.strip().lower()
    if "complete" not in roles_decision_text:
        if not roles_started:
            return roles_initial_question
        else:
            followup_prompt = roles_followup_template.format(chat_history=formatted_history)
            response = llm([roles_system_message, HumanMessage(content=followup_prompt)])
            return response.content

    # --- 3. Operasyonel Bilgi Kontrolü ---
    operational_started = any((not msg["isUser"]) and (operational_initial_question in msg["text"]) for msg in history)
    operational_decide_prompt = operational_decide_template.format(chat_history=formatted_history)
    operational_decision_response = llm([operational_system_message, HumanMessage(content=operational_decide_prompt)])
    operational_decision_text = operational_decision_response.content.strip().lower()
    if "complete" not in operational_decision_text:
        if not operational_started:
            return operational_initial_question
        else:
            followup_prompt = operational_followup_template.format(chat_history=formatted_history)
            response = llm([operational_system_message, HumanMessage(content=followup_prompt)])
            return response.content

    # --- 4. Üretim Bilgi Kontrolü ---
    production_started = any((not msg["isUser"]) and (production_initial_question in msg["text"]) for msg in history)
    production_decide_prompt = production_decide_template.format(chat_history=formatted_history)
    production_decision_response = llm([production_system_message, HumanMessage(content=production_decide_prompt)])
    production_decision_text = production_decision_response.content.strip().lower()
    if "complete" not in production_decision_text:
        if not production_started:
            return production_initial_question
        else:
            followup_prompt = production_followup_template.format(chat_history=formatted_history)
            response = llm([production_system_message, HumanMessage(content=followup_prompt)])
            return response.content

    # Tüm aşamalar tamamlandıysa, genel kapanış mesajı döndürelim.
    return "All required information has been collected. Thank you!"
