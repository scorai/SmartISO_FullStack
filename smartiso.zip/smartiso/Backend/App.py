from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from chatbot import get_bot_response
import uvicorn

app = FastAPI()

# CORS ayarlarını ekleyin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5174"],  # Frontend URL'iniz
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str
    history: list = []  # Opsiyonel: Sohbet geçmişi

@app.post("/chat")
async def chat_endpoint(chat_request: ChatRequest):
    try:
        response_text = get_bot_response(chat_request.message, chat_request.history)
        return {"response": response_text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("App:app", host="0.0.0.0", port=8000, reload=True)
