/*
  # Initial Schema for ISO Documentation System

  1. New Tables
    - organizations
      - Basic organization info and settings
    - documents
      - Stores document content and metadata
    - document_versions
      - Version history for documents
    - folders
      - Document organization structure
    - questionnaire_responses
      - Stores user responses for document generation

  2. Security
    - Enable RLS on all tables
    - Add policies for organization-based access
    - Ensure data isolation between organizations

  3. Changes
    - Initial schema creation
    - Basic folder structure setup
    - Document versioning support
*/

-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  industry text,
  size text,
  website text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  settings jsonb DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;

-- Organizations policies
CREATE POLICY "Users can view their own organization"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT user_id 
      FROM organization_members 
      WHERE organization_id = organizations.id
    )
  );

-- Folders table
CREATE TABLE IF NOT EXISTS folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  parent_id uuid REFERENCES folders(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (organization_id, parent_id, name)
);

-- Enable RLS
ALTER TABLE folders ENABLE ROW LEVEL SECURITY;

-- Folders policies
CREATE POLICY "Users can view folders in their organization"
  ON folders
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Editors can create folders"
  ON folders
  FOR INSERT
  TO authenticated
  WITH CHECK (
    organization_id IN (
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid() 
      AND role = 'editor'
    )
  );

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  folder_id uuid REFERENCES folders(id) ON DELETE SET NULL,
  title text NOT NULL,
  type text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_edited_by uuid REFERENCES auth.users(id),
  version integer NOT NULL DEFAULT 1,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Enable RLS
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Documents policies
CREATE POLICY "Users can view documents in their organization"
  ON documents
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Editors can create and update documents"
  ON documents
  FOR INSERT
  TO authenticated
  WITH CHECK (
    organization_id IN (
      SELECT organization_id 
      FROM organization_members 
      WHERE user_id = auth.uid() 
      AND role = 'editor'
    )
  );

-- Document versions table
CREATE TABLE IF NOT EXISTS document_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version integer NOT NULL,
  content jsonb NOT NULL,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  comment text,
  UNIQUE (document_id, version)
);

-- Enable RLS
ALTER TABLE document_versions ENABLE ROW LEVEL SECURITY;

-- Document versions policies
CREATE POLICY "Users can view document versions in their organization"
  ON document_versions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM documents d
      JOIN organization_members om ON om.organization_id = d.organization_id
      WHERE d.id = document_versions.document_id
      AND om.user_id = auth.uid()
    )
  );

-- Questionnaire responses table
CREATE TABLE IF NOT EXISTS questionnaire_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  responses jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE questionnaire_responses ENABLE ROW LEVEL SECURITY;

-- Questionnaire responses policies
CREATE POLICY "Users can view responses for their organization's documents"
  ON questionnaire_responses
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM documents d
      JOIN organization_members om ON om.organization_id = d.organization_id
      WHERE d.id = questionnaire_responses.document_id
      AND om.user_id = auth.uid()
    )
  );

-- Create default folders for new organizations
CREATE OR REPLACE FUNCTION create_default_folders()
RETURNS TRIGGER AS $$
BEGIN
  -- Create default top-level folders
  INSERT INTO folders (organization_id, name) VALUES
    (NEW.id, 'Quality Manual'),
    (NEW.id, 'Procedures'),
    (NEW.id, 'Work Instructions'),
    (NEW.id, 'Records');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER create_organization_folders
  AFTER INSERT ON organizations
  FOR EACH ROW
  EXECUTE FUNCTION create_default_folders();

-- Add indexes for performance
CREATE INDEX idx_folders_organization_id ON folders(organization_id);
CREATE INDEX idx_documents_organization_id ON documents(organization_id);
CREATE INDEX idx_documents_folder_id ON documents(folder_id);
CREATE INDEX idx_document_versions_document_id ON document_versions(document_id);