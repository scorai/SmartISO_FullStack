import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ClerkProvider, ClerkLoading, ClerkLoaded } from '@clerk/clerk-react';
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';

const PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

if (!PUBLISHABLE_KEY) {
  throw new Error('Missing Clerk Publishable Key');
}

const clerkAppearance = {
  baseTheme: undefined,
  variables: {
    colorPrimary: '#4f46e5',
    colorTextOnPrimaryBackground: 'white',
  },
  elements: {
    rootBox: "w-full",
    card: "bg-white shadow-lg rounded-lg p-8",
    headerTitle: "text-2xl font-bold text-gray-900 text-center",
    headerSubtitle: "text-gray-500 text-center mt-2",
    socialButtonsBlockButton: "w-full border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 rounded-lg px-4 py-2.5 text-sm font-medium",
    dividerRow: "hidden",
    formFieldInput: "w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-sm",
    formFieldLabel: "block text-sm font-medium text-gray-700",
    formButtonPrimary: "w-full bg-indigo-600 text-white rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors",
    footerAction: "text-center mt-4",
    footerActionLink: "text-indigo-600 hover:text-indigo-500 font-medium",
    formFieldError: "text-sm text-red-600",
    avatarBox: "w-20 h-20 rounded-lg bg-gray-100 flex items-center justify-center text-gray-400",
    avatarImagePlaceholder: "w-8 h-8",
    organizationSwitcherTrigger: "w-full flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50",
    userButtonTrigger: "flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 w-full",
    userButtonPopoverCard: "shadow-lg border border-gray-200",
    userButtonPopoverFooter: "border-t border-gray-200",
    organizationPreview: "flex items-center gap-3 p-2",
    organizationPreviewTextContainer: "flex flex-col",
    organizationList: "divide-y divide-gray-100",
    navbar: "bg-white border-b border-gray-200 mb-6",
    navbarButton: "px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:text-gray-900 focus:bg-gray-50",
    navbarButtonActive: "text-indigo-600 border-b-2 border-indigo-600"
  }
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <ClerkProvider 
        publishableKey={PUBLISHABLE_KEY}
        appearance={clerkAppearance}
      >
        <ClerkLoading>
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Loading authentication...</p>
            </div>
          </div>
        </ClerkLoading>
        <ClerkLoaded>
          <App />
        </ClerkLoaded>
      </ClerkProvider>
    </ErrorBoundary>
  </StrictMode>
);