import React, { useState } from 'react';
import { Search, Plus, Phone, Video, MoreVertical, Send, Paperclip, Smile } from 'lucide-react';

const Messages = () => {
  const [message, setMessage] = useState('');

  const conversations = [
    {
      id: 1,
      name: 'Design Team',
      lastMessage: 'Great work on the new mockups!',
      time: '10:30 AM',
      unread: 2,
      online: true,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&auto=format&fit=crop'
    },
    {
      id: 2,
      name: 'Development Team',
      lastMessage: 'When can we expect the API docs?',
      time: '9:45 AM',
      unread: 0,
      online: true,
      avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=100&auto=format&fit=crop'
    },
    {
      id: 3,
      name: 'Marketing Team',
      lastMessage: 'Campaign stats are looking good!',
      time: 'Yesterday',
      unread: 0,
      online: false,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=100&auto=format&fit=crop'
    }
  ];

  const messages = [
    {
      id: 1,
      sender: 'Sarah Thompson',
      content: "Hi team! How's the progress on the new features?",
      time: '10:30 AM',
      isMe: false
    },
    {
      id: 2,
      sender: 'Me',
      content: "Going well! We've completed the initial designs and started implementation.",
      time: '10:32 AM',
      isMe: true
    },
    {
      id: 3,
      sender: 'Michael Chen',
      content: 'Awesome! When can we schedule a review?',
      time: '10:35 AM',
      isMe: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-gray-200">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Messages</h2>
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
              <Plus className="h-5 w-5" />
            </button>
          </div>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search messages..."
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-2">
            {conversations.map((conversation) => (
              <div
                key={conversation.id}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
              >
                <div className="relative">
                  <img
                    src={conversation.avatar}
                    alt={conversation.name}
                    className="h-10 w-10 rounded-full"
                  />
                  {conversation.online && (
                    <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-white" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium truncate">{conversation.name}</h3>
                    <span className="text-xs text-gray-500">{conversation.time}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">{conversation.lastMessage}</p>
                </div>
                {conversation.unread > 0 && (
                  <div className="bg-indigo-600 text-white text-xs font-medium px-2 py-1 rounded-full">
                    {conversation.unread}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="bg-white border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={conversations[0].avatar}
                alt={conversations[0].name}
                className="h-10 w-10 rounded-full"
              />
              <div>
                <h3 className="font-medium">{conversations[0].name}</h3>
                <p className="text-sm text-gray-500">3 members • 2 online</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                <Phone className="h-5 w-5" />
              </button>
              <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                <Video className="h-5 w-5" />
              </button>
              <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                <MoreVertical className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[70%] ${msg.isMe ? 'bg-indigo-600 text-white' : 'bg-gray-100'} rounded-lg px-4 py-2`}>
                {!msg.isMe && (
                  <p className="text-sm font-medium mb-1">{msg.sender}</p>
                )}
                <p className="text-sm">{msg.content}</p>
                <p className={`text-xs ${msg.isMe ? 'text-indigo-200' : 'text-gray-500'} mt-1`}>
                  {msg.time}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="bg-white border-t border-gray-200 p-4">
          <div className="flex items-center gap-2">
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
              <Paperclip className="h-5 w-5" />
            </button>
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
              <Smile className="h-5 w-5" />
            </button>
            <button className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Messages;