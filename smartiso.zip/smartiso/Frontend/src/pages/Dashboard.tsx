import React from 'react';
import { 
  BarChart3, 
  Users, 
  Calendar, 
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Bell,
  Search,
  ChevronDown
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';

const data = [
  { name: 'Jan', value: 400 },
  { name: 'Feb', value: 300 },
  { name: 'Mar', value: 600 },
  { name: 'Apr', value: 800 },
  { name: 'May', value: 500 },
  { name: 'Jun', value: 700 },
];

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-soft-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-semibold">Dashboard</h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search..."
                className="pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 input-shadow"
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-500 hover:bg-gray-50 rounded-lg button-glow">
              <Bell className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <ChevronDown className="h-4 w-4 text-gray-500" />
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard
            title="Total Projects"
            value="45"
            change="+12.5%"
            trend="up"
            icon={BarChart3}
            color="blue"
          />
          <StatCard
            title="Total Members"
            value="24"
            change="+8.2%"
            trend="up"
            icon={Users}
            color="purple"
          />
          <StatCard
            title="Completed Tasks"
            value="128"
            change="-3.1%"
            trend="down"
            icon={CheckCircle2}
            color="green"
          />
          <StatCard
            title="Hours Logged"
            value="248"
            change="+14.8%"
            trend="up"
            icon={Clock}
            color="orange"
          />
        </div>

        {/* Chart */}
        <div className="bg-white p-6 rounded-xl shadow-soft-lg card-hover">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Project Progress</h2>
            <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 input-shadow">
              <option>Last 6 months</option>
              <option>Last 12 months</option>
              <option>All time</option>
            </select>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#4F46E5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ 
  title, 
  value, 
  change, 
  trend, 
  icon: Icon,
  color 
}: { 
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ElementType;
  color: string;
}) => (
  <div className="bg-white p-6 rounded-xl shadow-soft-lg card-hover">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-2 bg-${color}-50 rounded-lg shadow-soft-sm`}>
        <Icon className={`h-5 w-5 text-${color}-600`} />
      </div>
      <span className={`flex items-center gap-1 text-sm ${
        trend === 'up' ? 'text-green-600' : 'text-red-600'
      }`}>
        {trend === 'up' ? (
          <ArrowUpRight className="h-4 w-4" />
        ) : (
          <ArrowDownRight className="h-4 w-4" />
        )}
        {change}
      </span>
    </div>
    <h3 className="text-2xl font-semibold mb-1">{value}</h3>
    <p className="text-gray-500 text-sm">{title}</p>
  </div>
);

export default Dashboard;