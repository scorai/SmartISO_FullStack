import React from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { format, addDays, startOfWeek } from 'date-fns';

const Calendar = () => {
  const today = new Date();
  const weekStart = startOfWeek(today);
  
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  const events = [
    {
      id: 1,
      title: 'Team Meeting',
      time: '10:00 AM',
      duration: '1h',
      type: 'meeting',
    },
    {
      id: 2,
      title: 'Project Review',
      time: '2:00 PM',
      duration: '2h',
      type: 'review',
    },
    {
      id: 3,
      title: 'Client Call',
      time: '4:00 PM',
      duration: '30m',
      type: 'call',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Calendar</h1>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-lg">
                <ChevronLeft className="h-5 w-5 text-gray-500" />
              </button>
              <button className="px-4 py-2 font-medium">Today</button>
              <button className="p-2 hover:bg-gray-100 rounded-lg">
                <ChevronRight className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </div>
          
          {/* Week View */}
          <div className="grid grid-cols-7 gap-4">
            {weekDays.map((day, index) => (
              <div
                key={index}
                className={`text-center ${
                  format(day, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')
                    ? 'bg-indigo-50 rounded-lg'
                    : ''
                }`}
              >
                <div className="text-sm text-gray-500">{format(day, 'EEE')}</div>
                <div className={`text-lg font-semibold ${
                  format(day, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')
                    ? 'text-indigo-600'
                    : ''
                }`}>
                  {format(day, 'd')}
                </div>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Calendar Content */}
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm">
          {/* Events */}
          <div className="divide-y divide-gray-100">
            {events.map((event) => (
              <div key={event.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${
                      event.type === 'meeting' ? 'bg-blue-100' :
                      event.type === 'review' ? 'bg-purple-100' :
                      'bg-green-100'
                    }`}>
                      <CalendarIcon className={`h-5 w-5 ${
                        event.type === 'meeting' ? 'text-blue-600' :
                        event.type === 'review' ? 'text-purple-600' :
                        'text-green-600'
                      }`} />
                    </div>
                    <div>
                      <h3 className="font-medium">{event.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>{event.time}</span>
                        <span>·</span>
                        <span>{event.duration}</span>
                      </div>
                    </div>
                  </div>
                  <button className="text-sm text-indigo-600 hover:text-indigo-700 font-medium">
                    Join
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Calendar;