import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Plus, Search, Filter, FolderOpen } from 'lucide-react';

const Documents = () => {
  const documents = [
    { id: 1, title: 'Quality Manual', type: 'Manual', updatedAt: '2024-02-20', status: 'Published' },
    { id: 2, title: 'Process Map', type: 'Procedure', updatedAt: '2024-02-19', status: 'Draft' },
    { id: 3, title: 'Audit Checklist', type: 'Form', updatedAt: '2024-02-18', status: 'Review' },
    { id: 4, title: 'Risk Assessment', type: 'Template', updatedAt: '2024-02-17', status: 'Published' },
    { id: 5, title: 'Training Records', type: 'Record', updatedAt: '2024-02-16', status: 'Draft' },
  ];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Documents</h1>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors">
          <Plus className="h-5 w-5" />
          New Document
        </button>
      </div>

      <div className="flex gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Search documents..."
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Filter className="h-5 w-5 text-gray-500" />
          Filter
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 border-b border-gray-200 bg-gray-50 font-medium text-gray-600">
          <div className="col-span-5">Title</div>
          <div className="col-span-2">Type</div>
          <div className="col-span-2">Last Updated</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-1"></div>
        </div>
        
        {documents.map((doc) => (
          <Link
            key={doc.id}
            to={`/documents/${doc.id}`}
            className="grid grid-cols-12 gap-4 p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors items-center"
          >
            <div className="col-span-5 flex items-center gap-3">
              <FileText className="h-5 w-5 text-gray-400" />
              <span className="font-medium">{doc.title}</span>
            </div>
            <div className="col-span-2 text-gray-600">{doc.type}</div>
            <div className="col-span-2 text-gray-600">{doc.updatedAt}</div>
            <div className="col-span-2">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                doc.status === 'Published' ? 'bg-green-100 text-green-800' :
                doc.status === 'Draft' ? 'bg-gray-100 text-gray-800' :
                'bg-yellow-100 text-yellow-800'
              }`}>
                {doc.status}
              </span>
            </div>
            <div className="col-span-1 flex justify-end">
              <button className="text-gray-400 hover:text-gray-600">
                <FolderOpen className="h-5 w-5" />
              </button>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Documents;