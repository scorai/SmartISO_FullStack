import React from 'react';
import { SignUpButton } from '@clerk/clerk-react';
import { FileText, Shield, Lock, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    title: 'AI-Powered Documentation',
    description: 'Leverage advanced AI to create, manage, and improve your documentation automatically.',
    icon: FileText
  },
  {
    title: 'Enterprise Security',
    description: 'Bank-level security with advanced encryption and access controls.',
    icon: Shield
  },
  {
    title: 'Smart Collaboration',
    description: 'Real-time collaboration with AI-assisted workflows and version control.',
    icon: Lock
  }
];

const testimonial = {
  content: 'Aerodocs has transformed how we manage our documentation. The AI capabilities and intuitive interface have made our ISO compliance process seamless and efficient.',
  name: 'Sarah Thompson',
  role: 'Quality Assurance Director',
  image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&auto=format&fit=crop'
};

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              AI-Powered Documentation
              <br />
              <span className="text-indigo-600">for the Modern Team</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Create, manage, and improve your documentation with the power of AI.
              Streamline your workflow and boost productivity.
            </p>
            <SignUpButton mode="modal">
              <button className="inline-flex items-center px-8 py-3 border border-transparent text-lg font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-lg hover:shadow-xl">
                Get Started Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </SignUpButton>
          </motion.div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">
              Everything you need to manage documentation
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Powerful features to help you write, organize, and share documentation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-gray-50 p-8 rounded-xl"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Testimonial Section */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">
              What our users say
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Discover how Aerodocs transforms documentation management
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg"
          >
            <p className="text-xl text-gray-600 mb-8">"{testimonial.content}"</p>
            <div className="flex items-center">
              <img
                src={testimonial.image}
                alt={testimonial.name}
                className="w-16 h-16 rounded-full"
              />
              <div className="ml-4">
                <h4 className="text-lg font-semibold text-gray-900">
                  {testimonial.name}
                </h4>
                <p className="text-gray-600">{testimonial.role}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;