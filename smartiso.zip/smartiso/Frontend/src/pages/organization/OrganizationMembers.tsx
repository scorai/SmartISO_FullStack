import React, { useState } from 'react';
import { useOrganization } from '@clerk/clerk-react';
import { Plus, Search, Shield, Trash2, Mail } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Member {
  id: string;
  role: string;
  publicMetadata: Record<string, any>;
  publicUserData: {
    firstName?: string;
    lastName?: string;
    email?: string;
  };
}

const OrganizationMembers = () => {
  const { organization, membership, isLoaded } = useOrganization();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const isAdmin = membership?.role === 'org:admin';

  const handleInviteMember = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      await organization?.inviteMember({ 
        emailAddress: inviteEmail,
        role: 'org:basic_member'
      });
      setInviteEmail('');
      setShowInviteModal(false);
    } catch (error) {
      setError('Failed to send invitation. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateRole = async (memberId: string, newRole: string) => {
    try {
      await organization?.updateMember(memberId, { role: newRole });
    } catch (error) {
      console.error('Error updating member role:', error);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    try {
      await organization?.removeMember(memberId);
    } catch (error) {
      console.error('Error removing member:', error);
    }
  };

  const filteredMembers = organization?.memberships?.filter((member: Member) => {
    const matchesSearch = 
      member.publicUserData.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      `${member.publicUserData.firstName} ${member.publicUserData.lastName}`
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
    
    const matchesRole = !selectedRole || member.role === selectedRole;
    
    return matchesSearch && matchesRole;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-soft-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Organization Members</h1>
            {isAdmin && (
              <button 
                onClick={() => setShowInviteModal(true)}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 button-glow"
              >
                <Plus className="h-5 w-5" />
                Invite Member
              </button>
            )}
          </div>
          
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search members..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 input-shadow"
              />
            </div>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 input-shadow"
            >
              <option value="">All Roles</option>
              <option value="org:admin">Admin</option>
              <option value="org:basic_member">Member</option>
            </select>
          </div>
        </div>
      </header>

      {/* Members List */}
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-soft-lg">
          <div className="divide-y divide-gray-100">
            <AnimatePresence>
              {filteredMembers?.map((member: Member) => (
                <motion.div
                  key={member.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="p-6 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-indigo-50 rounded-lg shadow-soft-sm">
                        <Mail className="h-5 w-5 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">
                          {member.publicUserData.firstName} {member.publicUserData.lastName}
                        </h3>
                        <p className="text-sm text-gray-500">{member.publicUserData.email}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{
                          member.role === 'org:admin' ? 'Admin' : 'Member'
                        }</span>
                      </div>
                      
                      {isAdmin && member.id !== membership?.id && (
                        <div className="flex items-center gap-2">
                          <select
                            value={member.role}
                            onChange={(e) => handleUpdateRole(member.id, e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-2 py-1 input-shadow"
                          >
                            <option value="org:admin">Admin</option>
                            <option value="org:basic_member">Member</option>
                          </select>
                          
                          <button
                            onClick={() => handleRemoveMember(member.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white rounded-xl shadow-soft-xl p-6 max-w-md w-full"
          >
            <h2 className="text-xl font-semibold mb-4">Invite New Member</h2>
            {error && (
              <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
                {error}
              </div>
            )}
            <form onSubmit={handleInviteMember}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 input-shadow"
                  placeholder="Enter email address"
                  required
                />
              </div>
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors button-glow disabled:opacity-50"
                >
                  {isLoading ? 'Sending...' : 'Send Invitation'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default OrganizationMembers;