import React from 'react';
import { OrganizationProfile } from '@clerk/clerk-react';
import { FileText, HelpCircle, Globe, Book, MessageSquare, Users, Settings } from 'lucide-react';
import OrganizationMembers from './OrganizationMembers';

const OrganizationProfilePage = () => {
  return (
    <div className="p-8">
      <OrganizationProfile
        appearance={{
          elements: {
            rootBox: "w-full",
            card: "bg-white shadow-lg rounded-lg",
            headerTitle: "text-2xl font-bold text-gray-900",
            headerSubtitle: "text-gray-500 mt-2",
            formButtonPrimary: "bg-indigo-600 text-white rounded-lg px-4 py-2 hover:bg-indigo-700 button-glow",
            formFieldInput: "w-full mt-1 block rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 input-shadow",
            formFieldLabel: "block text-sm font-medium text-gray-700",
            organizationSwitcherTrigger: "flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 button-glow",
            organizationPreview: "flex items-center gap-3 p-2",
            organizationPreviewTextContainer: "flex flex-col",
            avatarBox: "flex items-center justify-center w-10 h-10 rounded-lg bg-gray-100 text-gray-600",
            organizationList: "divide-y divide-gray-100",
            navbar: "bg-white border-b border-gray-200 mb-6",
            navbarButton: "px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:text-gray-900 focus:bg-gray-50",
            navbarButtonActive: "text-indigo-600 border-b-2 border-indigo-600"
          }
        }}
      >
        {/* Members Page */}
        <OrganizationProfile.Page
          label="Members"
          labelIcon={<Users className="h-4 w-4" />}
          url="members"
        >
          <OrganizationMembers />
        </OrganizationProfile.Page>

        {/* Documentation Page */}
        <OrganizationProfile.Page
          label="Documentation"
          labelIcon={<Book className="h-4 w-4" />}
          url="documentation"
        >
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Documentation</h1>
            <p className="text-gray-600">
              Access all your organization's documentation and resources in one place.
            </p>
          </div>
        </OrganizationProfile.Page>

        {/* Help Page */}
        <OrganizationProfile.Page
          label="Help & Support"
          labelIcon={<HelpCircle className="h-4 w-4" />}
          url="help"
        >
          <div className="space-y-6">
            <h1 className="text-2xl font-bold">Help & Support</h1>
            <p className="text-gray-600">
              Get help with your organization's settings and management.
            </p>
          </div>
        </OrganizationProfile.Page>

        {/* External Links */}
        <OrganizationProfile.Link
          label="Knowledge Base"
          labelIcon={<Globe className="h-4 w-4" />}
          url="https://docs.example.com"
        />
        
        <OrganizationProfile.Link
          label="Support Chat"
          labelIcon={<MessageSquare className="h-4 w-4" />}
          url="/chatbot"
        />
      </OrganizationProfile>
    </div>
  );
};

export default OrganizationProfilePage;