import React from 'react';
import { Mail } from 'lucide-react';
import SettingsLayout from './SettingsLayout';

const EmailSettings = () => {
  return (
    <SettingsLayout
      title="Email Settings"
      description="Manage your email preferences"
      icon={Mail}
      color="red"
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Email Frequency</h3>
            <p className="text-sm text-gray-500">How often you want to receive emails</p>
          </div>
          <select className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
            <option>Immediately</option>
            <option>Daily Digest</option>
            <option>Weekly Summary</option>
          </select>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Email Format</h3>
            <p className="text-sm text-gray-500">Choose your preferred email format</p>
          </div>
          <select className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
            <option>HTML</option>
            <option>Plain Text</option>
          </select>
        </div>
      </div>
    </SettingsLayout>
  );
};

export default EmailSettings;