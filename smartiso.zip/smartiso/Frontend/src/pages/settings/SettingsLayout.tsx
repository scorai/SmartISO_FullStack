import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface SettingsLayoutProps {
  title: string;
  description: string;
  icon: LucideIcon;
  color?: string;
  children: React.ReactNode;
}

const SettingsLayout: React.FC<SettingsLayoutProps> = ({
  title,
  description,
  icon: Icon,
  color = "indigo",
  children
}) => {
  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className={`p-2 bg-${color}-50 rounded-lg`}>
                <Icon className={`h-5 w-5 text-${color}-600`} />
              </div>
              <div>
                <h2 className="text-lg font-semibold">{title}</h2>
                <p className="text-sm text-gray-500">{description}</p>
              </div>
            </div>
          </div>
          <div className="p-6">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsLayout;