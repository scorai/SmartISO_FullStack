import React from 'react';
import { Shield } from 'lucide-react';
import SettingsLayout from './SettingsLayout';

const DangerZone = () => {
  return (
    <SettingsLayout
      title="Danger Zone"
      description="Irreversible and destructive actions"
      icon={Shield}
      color="red"
    >
      <div className="space-y-4">
        <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
          <div>
            <h3 className="text-sm font-medium text-red-800">Delete Account</h3>
            <p className="text-sm text-red-600">
              Permanently delete your account and all associated data
            </p>
          </div>
          <button 
            className="px-4 py-2 text-sm font-medium text-red-600 bg-white border border-red-300 rounded-lg hover:bg-red-50"
          >
            Delete Account
          </button>
        </div>
      </div>
    </SettingsLayout>
  );
};

export default DangerZone;