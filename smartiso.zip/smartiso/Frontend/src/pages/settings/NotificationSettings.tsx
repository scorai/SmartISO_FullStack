import React, { useState } from 'react';
import { Bell } from 'lucide-react';
import SettingsLayout from './SettingsLayout';

const NotificationSettings = () => {
  const [emailNotifications, setEmailNotifications] = useState({
    security: true,
    updates: true,
    marketing: false
  });

  return (
    <SettingsLayout
      title="Notification Settings"
      description="Control your notification preferences"
      icon={Bell}
      color="yellow"
    >
      <div className="space-y-4">
        {Object.entries(emailNotifications).map(([key, enabled]) => (
          <div key={key} className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-medium text-gray-900 capitalize">{key} Notifications</h3>
              <p className="text-sm text-gray-500">
                Receive notifications about {key.toLowerCase()} updates
              </p>
            </div>
            <button
              onClick={() => setEmailNotifications(prev => ({ ...prev, [key]: !prev[key] }))}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${
                enabled ? 'bg-indigo-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  enabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        ))}
      </div>
    </SettingsLayout>
  );
};

export default NotificationSettings;