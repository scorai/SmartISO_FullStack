import React from 'react';
import { Shield, Loader2, Monitor, Smartphone, Laptop } from 'lucide-react';
import { useSession, useSessionList } from '@clerk/clerk-react';
import SettingsLayout from './SettingsLayout';

const SessionSettings = () => {
  const { isLoaded: isSessionLoaded, session } = useSession();
  const { isLoaded: isSessionListLoaded, sessions } = useSessionList();

  return (
    <SettingsLayout
      title="Active Sessions"
      description="Manage your active sessions across different devices"
      icon={Shield}
      color="teal"
    >
      {!isSessionLoaded || !isSessionListLoaded ? (
        <div className="flex items-center justify-center p-4">
          <Loader2 className="h-6 w-6 animate-spin text-indigo-600" />
        </div>
      ) : (
        <div className="space-y-4">
          {sessions.map((s) => {
            const DeviceIcon = s.lastActiveAt.toString().includes('Mobile') ? Smartphone : 
                             s.lastActiveAt.toString().includes('Tablet') ? Monitor : Laptop;
            const isCurrentSession = s.id === session?.id;
            
            return (
              <div
                key={s.id}
                className={`flex items-center justify-between p-4 rounded-lg ${
                  isCurrentSession ? 'bg-indigo-50 border border-indigo-100' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${isCurrentSession ? 'bg-indigo-100' : 'bg-gray-200'}`}>
                    <DeviceIcon className={`h-5 w-5 ${isCurrentSession ? 'text-indigo-600' : 'text-gray-600'}`} />
                  </div>
                  <div>
                    <p className="font-medium">
                      {isCurrentSession ? 'Current Session' : 'Other Device'}
                      {isCurrentSession && (
                        <span className="ml-2 text-xs bg-indigo-100 text-indigo-600 px-2 py-1 rounded-full">
                          Active
                        </span>
                      )}
                    </p>
                    <p className="text-sm text-gray-500">
                      Last active {new Date(s.lastActiveAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                {!isCurrentSession && (
                  <button
                    onClick={() => s.revoke()}
                    className="px-3 py-1 text-sm text-red-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors"
                  >
                    End Session
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </SettingsLayout>
  );
};

export default SessionSettings;