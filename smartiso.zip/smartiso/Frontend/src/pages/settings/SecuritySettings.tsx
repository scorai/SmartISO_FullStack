import React from 'react';
import { Lock } from 'lucide-react';
import SettingsLayout from './SettingsLayout';

const SecuritySettings = () => {
  return (
    <SettingsLayout
      title="Security Settings"
      description="Manage your security preferences"
      icon={Lock}
      color="green"
    >
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Two-Factor Authentication</h3>
            <p className="text-sm text-gray-500">Add an extra layer of security to your account</p>
          </div>
          <button className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700">
            Enable
          </button>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-gray-900">Password Requirements</h3>
            <p className="text-sm text-gray-500">Set minimum password strength requirements</p>
          </div>
          <button className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200">
            Configure
          </button>
        </div>
      </div>
    </SettingsLayout>
  );
};

export default SecuritySettings;