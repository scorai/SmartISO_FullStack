import React from 'react';
import { Building } from 'lucide-react';
import SettingsLayout from './SettingsLayout';

const OrganizationSettings = () => {
  return (
    <SettingsLayout
      title="Organization Settings"
      description="Manage your organization details"
      icon={Building}
      color="purple"
    >
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Organization Name</label>
          <input
            type="text"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            placeholder="Your organization"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Industry</label>
          <select
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          >
            <option>Technology</option>
            <option>Healthcare</option>
            <option>Manufacturing</option>
            <option>Education</option>
          </select>
        </div>
      </div>
    </SettingsLayout>
  );
};

export default OrganizationSettings;