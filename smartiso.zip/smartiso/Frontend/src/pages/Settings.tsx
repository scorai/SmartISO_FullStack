import React from 'react';
import { Link } from 'react-router-dom';
import { 
  User, Building, Lock, Bell, Mail, Globe, Shield
} from 'lucide-react';

const Settings = () => {
  const settingsLinks = [
    {
      to: '/settings/profile',
      icon: User,
      title: 'Profile Settings',
      description: 'Update your personal information',
      color: 'blue'
    },
    {
      to: '/settings/organization',
      icon: Building,
      title: 'Organization Settings',
      description: 'Manage your organization details',
      color: 'purple'
    },
    {
      to: '/settings/security',
      icon: Lock,
      title: 'Security Settings',
      description: 'Configure security settings and authentication methods',
      color: 'green'
    },
    {
      to: '/settings/notifications',
      icon: Bell,
      title: 'Notification Settings',
      description: 'Control how you receive alerts and notifications',
      color: 'yellow'
    },
    {
      to: '/settings/email',
      icon: Mail,
      title: 'Email Settings',
      description: 'Customize your email preferences and notifications',
      color: 'red'
    },
    {
      to: '/settings/language',
      icon: Globe,
      title: 'Language & Region',
      description: 'Set your preferred language and regional settings',
      color: 'indigo'
    },
    {
      to: '/settings/sessions',
      icon: Shield,
      title: 'Active Sessions',
      description: 'Manage your active sessions across different devices',
      color: 'teal'
    },
    {
      to: '/settings/danger-zone',
      icon: Shield,
      title: 'Danger Zone',
      description: 'Irreversible and destructive actions',
      color: 'red'
    }
  ];

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Settings</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {settingsLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.to}
                to={link.to}
                className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="p-6">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 bg-${link.color}-50 rounded-lg`}>
                      <Icon className={`h-5 w-5 text-${link.color}-600`} />
                    </div>
                    <div>
                      <h2 className="text-lg font-semibold">{link.title}</h2>
                      <p className="text-sm text-gray-500">{link.description}</p>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Settings;