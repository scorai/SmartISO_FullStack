import React from 'react';
import { useParams } from 'react-router-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import Document from '@tiptap/extension-document';
import Paragraph from '@tiptap/extension-paragraph';
import Text from '@tiptap/extension-text';
import Placeholder from '@tiptap/extension-placeholder';
import { Save, ArrowLeft, Share2, MoreVertical } from 'lucide-react';

const Editor = () => {
  const { id } = useParams();
  
  const editor = useEditor({
    extensions: [
      Document,
      Paragraph,
      Text,
      Placeholder.configure({
        placeholder: 'Start typing your document...',
      }),
    ],
    content: '<p>Welcome to the ISO documentation editor!</p>',
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none',
      },
    },
  });

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="border-b border-gray-200 bg-white">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="py-4 flex items-center justify-between">
            <div className="flex items-center">
              <button className="text-gray-500 hover:text-gray-600 p-2 rounded-lg">
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="ml-4">
                <h1 className="text-lg font-semibold text-gray-900">Document #{id}</h1>
                <p className="text-sm text-gray-500">Last edited 2 hours ago</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </button>
              <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                <Save className="h-4 w-4 mr-2" />
                Save
              </button>
              <button className="text-gray-500 hover:text-gray-600 p-2 rounded-lg">
                <MoreVertical className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Editor Content */}
      <div className="flex-1 overflow-auto bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <EditorContent editor={editor} className="min-h-[500px]" />
        </div>
      </div>
    </div>
  );
};

export default Editor;