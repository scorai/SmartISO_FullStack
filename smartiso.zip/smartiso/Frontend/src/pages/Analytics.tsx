import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Calendar
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Legend
} from 'recharts';

const Analytics = () => {
  const projectData = [
    { name: 'Jan', completed: 45, active: 35 },
    { name: 'Feb', completed: 52, active: 28 },
    { name: 'Mar', completed: 48, active: 42 },
    { name: 'Apr', completed: 61, active: 31 },
    { name: 'May', completed: 55, active: 38 },
    { name: 'Jun', completed: 67, active: 45 },
  ];

  const timeData = [
    { name: 'Mon', hours: 6.5 },
    { name: 'Tue', hours: 7.2 },
    { name: 'Wed', hours: 8.1 },
    { name: 'Thu', hours: 6.8 },
    { name: 'Fri', hours: 7.5 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <h1 className="text-2xl font-semibold mb-4">Analytics</h1>
          <div className="flex gap-4">
            <select className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 3 months</option>
              <option>Last 12 months</option>
            </select>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <StatCard
            title="Total Projects"
            value="45"
            change="+12.5%"
            trend="up"
            icon={BarChart3}
            color="blue"
          />
          <StatCard
            title="Team Members"
            value="24"
            change="+8.2%"
            trend="up"
            icon={Users}
            color="purple"
          />
          <StatCard
            title="Hours Logged"
            value="248"
            change="-3.1%"
            trend="down"
            icon={Clock}
            color="orange"
          />
          <StatCard
            title="Active Tasks"
            value="32"
            change="+14.8%"
            trend="up"
            icon={Calendar}
            color="green"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Project Status Chart */}
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Project Status</h2>
              <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                <option>Last 6 months</option>
                <option>Last 12 months</option>
              </select>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={projectData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="completed" name="Completed" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="active" name="Active" fill="#818CF8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Time Tracking Chart */}
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Time Tracking</h2>
              <select className="text-sm border border-gray-200 rounded-lg px-3 py-2">
                <option>This Week</option>
                <option>Last Week</option>
              </select>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={timeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="hours" 
                    name="Hours" 
                    stroke="#4F46E5" 
                    strokeWidth={2}
                    dot={{ fill: '#4F46E5', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ 
  title, 
  value, 
  change, 
  trend, 
  icon: Icon,
  color 
}: { 
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ElementType;
  color: string;
}) => (
  <div className="bg-white p-6 rounded-xl shadow-sm">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-2 bg-${color}-50 rounded-lg`}>
        <Icon className={`h-5 w-5 text-${color}-600`} />
      </div>
      <span className={`flex items-center gap-1 text-sm ${
        trend === 'up' ? 'text-green-600' : 'text-red-600'
      }`}>
        {trend === 'up' ? (
          <ArrowUpRight className="h-4 w-4" />
        ) : (
          <ArrowDownRight className="h-4 w-4" />
        )}
        {change}
      </span>
    </div>
    <h3 className="text-2xl font-semibold mb-1">{value}</h3>
    <p className="text-gray-500 text-sm">{title}</p>
  </div>
);

export default Analytics;