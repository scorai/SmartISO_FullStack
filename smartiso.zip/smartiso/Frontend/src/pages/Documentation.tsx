import React from 'react';
import { Book, Search, Filter, Plus, FileText, FolderOpen, Clock, Users } from 'lucide-react';

const Documentation = () => {
  const documents = [
    {
      id: 1,
      title: 'Getting Started Guide',
      category: 'Guides',
      lastUpdated: '2024-03-15',
      contributors: 3,
      status: 'Published'
    },
    {
      id: 2,
      title: 'API Documentation',
      category: 'Technical',
      lastUpdated: '2024-03-14',
      contributors: 5,
      status: 'Draft'
    },
    {
      id: 3,
      title: 'Security Guidelines',
      category: 'Policies',
      lastUpdated: '2024-03-13',
      contributors: 2,
      status: 'Review'
    },
    {
      id: 4,
      title: 'User Manual',
      category: 'Guides',
      lastUpdated: '2024-03-12',
      contributors: 4,
      status: 'Published'
    }
  ];

  const categories = [
    { name: 'All Documents', count: 28 },
    { name: 'Guides', count: 12 },
    { name: 'Technical', count: 8 },
    { name: 'Policies', count: 5 },
    { name: 'Templates', count: 3 }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-soft-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Documentation</h1>
            <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 button-glow">
              <Plus className="h-5 w-5" />
              New Document
            </button>
          </div>
          
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search documentation..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 input-shadow"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 button-glow">
              <Filter className="h-5 w-5 text-gray-500" />
              Filter
            </button>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <div className="w-64">
            <div className="bg-white rounded-xl shadow-soft-lg p-6">
              <h2 className="text-lg font-semibold mb-4">Categories</h2>
              <nav className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.name}
                    className="flex items-center justify-between w-full px-3 py-2 text-sm rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <span className="text-gray-700">{category.name}</span>
                    <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs">
                      {category.count}
                    </span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <div className="bg-white rounded-xl shadow-soft-lg">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="p-6 border-b border-gray-100 last:border-0 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-indigo-50 rounded-lg">
                        <Book className="h-5 w-5 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">{doc.title}</h3>
                        <p className="text-sm text-gray-500">{doc.category}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>{doc.lastUpdated}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <Users className="h-4 w-4" />
                        <span>{doc.contributors} contributors</span>
                      </div>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        doc.status === 'Published' ? 'bg-green-100 text-green-800' :
                        doc.status === 'Draft' ? 'bg-gray-100 text-gray-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {doc.status}
                      </span>
                      <button className="text-gray-400 hover:text-gray-600">
                        <FolderOpen className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Documentation;