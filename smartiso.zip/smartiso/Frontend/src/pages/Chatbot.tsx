import React, { useState, useEffect } from "react";
import {
  Send,
  Mic,
  MicOff,
  Settings,
  Sun,
  Download,
  User,
  MessageSquare,
} from "lucide-react";
import { motion } from "framer-motion";

const Chatbot = () => {
  // Başlangıçta mesajlar dizisini boş tanımlıyoruz.
  const [messages, setMessages] = useState<
    Array<{ text: string; isUser: boolean; timestamp: string }>
  >([]);
  const [input, setInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(
    null
  );

  // Component mount olduğunda backend'den initial soruyu çekiyoruz.
  useEffect(() => {
    async function fetchInitialQuestion() {
      try {
        const response = await fetch("http://localhost:8000/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: "", history: [] }),
        });
        if (!response.ok) {
          throw new Error("Initial question fetch failed");
        }
        const data = await response.json();
        const botMessage = {
          text: data.response,
          isUser: false,
          timestamp: new Date().toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
          }),
        };
        setMessages([botMessage]);
      } catch (error) {
        console.error("Error fetching initial question:", error);
      }
    }
    fetchInitialQuestion();
  }, []);

  useEffect(() => {
    if (window.SpeechRecognition || window.webkitSpeechRecognition) {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = true;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = "en-US";

      recognitionInstance.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map((result) => result[0])
          .map((result) => result.transcript)
          .join("");
        setInput(transcript);
      };

      recognitionInstance.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const toggleListening = () => {
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  const handleSend = async () => {
    if (input.trim()) {
      // Kullanıcı mesajını anında ekle
      const userMessage = {
        text: input,
        isUser: true,
        timestamp: new Date().toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        }),
      };
      // Mevcut mesajları koruyup kullanıcı mesajını ekliyoruz.
      const updatedMessages = [...messages, userMessage];
      setMessages(updatedMessages);

      // Mesajı backend'e gönderiyoruz; mevcut history'yi de gönderiyoruz.
      try {
        const response = await fetch("http://localhost:8000/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message: input, history: updatedMessages }),
        });

        if (!response.ok) {
          throw new Error("Backend API ile bağlantı kurulamadı.");
        }

        const data = await response.json();
        const botMessage = {
          text: data.response,
          isUser: false,
          timestamp: new Date().toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
          }),
        };
        setMessages((prev) => [...prev, botMessage]);
      } catch (error) {
        console.error("Chatbot API error:", error);
      }

      setInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-soft-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <MessageSquare className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold">ISO Assistant</h1>
                <p className="text-sm text-gray-500">
                  AI-powered ISO documentation help
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <Sun className="h-5 w-5 text-gray-600" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <Settings className="h-5 w-5 text-gray-600" />
              </button>
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors">
                <Download className="h-4 w-4" />
                Export Chat
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="container mx-auto max-w-6xl p-6">
        <div className="bg-white rounded-xl shadow-soft-lg min-h-[calc(100vh-12rem)]">
          {/* Messages */}
          <div className="h-[calc(100vh-16rem)] overflow-y-auto p-6">
            <div className="space-y-6">
              {messages.map((message, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex ${
                    message.isUser ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`flex gap-3 max-w-[80%] ${
                      message.isUser ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                        message.isUser ? "bg-indigo-100" : "bg-gray-100"
                      }`}
                    >
                      {message.isUser ? (
                        <User className="h-5 w-5 text-indigo-600" />
                      ) : (
                        <MessageSquare className="h-5 w-5 text-gray-600" />
                      )}
                    </div>
                    <div
                      className={`flex flex-col ${
                        message.isUser ? "items-end" : "items-start"
                      }`}
                    >
                      <div
                        className={`p-4 rounded-2xl ${
                          message.isUser
                            ? "bg-indigo-600 text-white"
                            : "bg-white border border-gray-200 shadow-soft-sm"
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                      </div>
                      <span className="text-xs text-gray-500 mt-1">
                        {message.timestamp}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="border-t border-gray-200 p-6">
            <div className="bg-gray-50 border border-gray-200 rounded-xl shadow-soft-sm p-4">
              <div className="flex items-center gap-4">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask about ISO documentation..."
                  className="flex-1 bg-transparent text-sm focus:outline-none"
                />
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleListening}
                    className={`p-2 rounded-lg transition-colors ${
                      isListening
                        ? "bg-red-100 text-red-600 hover:bg-red-200"
                        : "hover:bg-gray-200 text-gray-400"
                    }`}
                  >
                    {isListening ? (
                      <MicOff className="h-5 w-5" />
                    ) : (
                      <Mic className="h-5 w-5" />
                    )}
                  </button>
                  <button
                    onClick={handleSend}
                    className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 transition-colors button-glow"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
