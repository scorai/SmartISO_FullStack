import React from 'react';
import { Plus, Search, Filter, MoreVertical, Calendar, CheckCircle2, Clock } from 'lucide-react';

const Tasks = () => {
  const tasks = [
    {
      id: 1,
      title: 'Design System Implementation',
      description: 'Create and implement design system components',
      priority: 'High',
      dueDate: '2024-03-20',
      status: 'In Progress',
      assignee: {
        name: 'Sarah Thompson',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&auto=format&fit=crop'
      }
    },
    {
      id: 2,
      title: 'User Research',
      description: 'Conduct user interviews and analyze feedback',
      priority: 'Medium',
      dueDate: '2024-03-22',
      status: 'Todo',
      assignee: {
        name: 'Michael Chen',
        avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=100&auto=format&fit=crop'
      }
    },
    {
      id: 3,
      title: 'API Documentation',
      description: 'Update API documentation with new endpoints',
      priority: 'Low',
      dueDate: '2024-03-25',
      status: 'Review',
      assignee: {
        name: 'Emily Davis',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=100&auto=format&fit=crop'
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Tasks</h1>
            <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
              <Plus className="h-5 w-5" />
              New Task
            </button>
          </div>
          
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search tasks..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
              <Filter className="h-5 w-5 text-gray-500" />
              Filter
            </button>
          </div>
        </div>
      </header>

      {/* Tasks List */}
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm">
          <div className="divide-y divide-gray-100">
            {tasks.map((task) => (
              <div key={task.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button className={`p-1 rounded-full ${
                      task.status === 'Completed' ? 'text-green-600' : 'text-gray-400 hover:text-gray-600'
                    }`}>
                      <CheckCircle2 className="h-5 w-5" />
                    </button>
                    <div>
                      <h3 className="font-medium">{task.title}</h3>
                      <p className="text-sm text-gray-500">{task.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <img
                        src={task.assignee.avatar}
                        alt={task.assignee.name}
                        className="h-8 w-8 rounded-full"
                      />
                      <span className="text-sm text-gray-600">{task.assignee.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4" />
                      <span>{task.dueDate}</span>
                    </div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      task.priority === 'High' ? 'bg-red-100 text-red-800' :
                      task.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {task.priority}
                    </span>
                    <button className="text-gray-400 hover:text-gray-600">
                      <MoreVertical className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tasks;