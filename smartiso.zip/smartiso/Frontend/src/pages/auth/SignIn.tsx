import React from 'react';
import { SignIn } from '@clerk/clerk-react';
import { FileText } from 'lucide-react';

const SignInPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="flex min-h-screen">
        {/* Left side - Sign In Form */}
        <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-md w-full space-y-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-6">
                <FileText className="h-8 w-8 text-indigo-600" />
                <h1 className="text-2xl font-bold text-gray-900">ISO Docs</h1>
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Welcome back</h2>
              <p className="mt-2 text-sm text-gray-600">
                Sign in to your account to continue
              </p>
            </div>

            <SignIn 
              appearance={{
                elements: {
                  rootBox: "w-full",
                  card: "w-full space-y-6",
                  headerTitle: "hidden",
                  headerSubtitle: "hidden",
                  socialButtonsBlockButton: "w-full border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 rounded-lg px-4 py-2.5 text-sm font-medium",
                  dividerRow: "hidden",
                  formFieldInput: "w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-sm",
                  formFieldLabel: "block text-sm font-medium text-gray-700",
                  formButtonPrimary: "w-full bg-indigo-600 text-white rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors",
                  footerAction: "text-center mt-4",
                  footerActionLink: "text-indigo-600 hover:text-indigo-500 font-medium",
                  formFieldError: "text-sm text-red-600"
                }
              }}
            />

            <div className="text-center">
              <p className="text-sm text-gray-500">
                By signing in, you agree to our{' '}
                <a href="#" className="text-indigo-600 hover:text-indigo-500 font-medium">
                  Terms of Service
                </a>{' '}
                and{' '}
                <a href="#" className="text-indigo-600 hover:text-indigo-500 font-medium">
                  Privacy Policy
                </a>
              </p>
            </div>
          </div>
        </div>

        {/* Right side - Background Image */}
        <div className="hidden lg:block relative flex-1">
          <div className="absolute inset-0">
            <img
              className="h-full w-full object-cover"
              src="https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3540&q=80"
              alt="Office workspace"
            />
            <div className="absolute inset-0 bg-indigo-900 mix-blend-multiply opacity-20"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center p-16">
            <blockquote className="relative max-w-lg">
              <div className="relative z-10">
                <p className="text-xl font-medium text-white">
                  "ISO Docs has transformed how we manage our documentation. The platform's intuitive interface and powerful features have made our ISO compliance process seamless and efficient."
                </p>
                <footer className="mt-6">
                  <p className="text-base font-medium text-white">Sarah Thompson</p>
                  <p className="text-sm text-indigo-100">Quality Manager at TechCorp</p>
                </footer>
              </div>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignInPage;