import React from 'react';
import { SignUp } from '@clerk/clerk-react';
import { FileText, Shield, Lock } from 'lucide-react';

const SignUpPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="flex min-h-screen">
        {/* Left side - Sign Up Form */}
        <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-md w-full space-y-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-6">
                <FileText className="h-8 w-8 text-indigo-600" />
                <h1 className="text-2xl font-bold text-gray-900">ISO Docs</h1>
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Create your account</h2>
              <p className="mt-2 text-sm text-gray-600">
                Join ISO Docs to streamline your documentation process
              </p>
            </div>

            <SignUp
              routing="path"
              path="/sign-up"
              signInUrl="/sign-in"
              redirectUrl="/dashboard"
              appearance={{
                elements: {
                  rootBox: "w-full",
                  card: "w-full space-y-6",
                  headerTitle: "hidden",
                  headerSubtitle: "hidden",
                  socialButtonsBlockButton: "w-full border border-gray-300 bg-white text-gray-700 hover:bg-gray-50 rounded-lg px-4 py-2.5 text-sm font-medium",
                  dividerRow: "hidden",
                  formFieldInput: "w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-sm",
                  formFieldLabel: "block text-sm font-medium text-gray-700",
                  formButtonPrimary: "w-full bg-indigo-600 text-white rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors",
                  footerAction: "text-center mt-4",
                  footerActionLink: "text-indigo-600 hover:text-indigo-500 font-medium",
                  formFieldError: "text-sm text-red-600"
                }
              }}
            />

            <div className="space-y-6 bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Shield className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Enterprise-grade Security</h3>
                  <p className="text-sm text-gray-500">Your data is protected with the highest standards</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Lock className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">ISO Compliance</h3>
                  <p className="text-sm text-gray-500">Built-in tools for maintaining ISO standards</p>
                </div>
              </div>
            </div>

            <div className="text-center">
              <p className="text-sm text-gray-500">
                By signing up, you agree to our{' '}
                <a href="#" className="text-indigo-600 hover:text-indigo-500 font-medium">
                  Terms of Service
                </a>{' '}
                and{' '}
                <a href="#" className="text-indigo-600 hover:text-indigo-500 font-medium">
                  Privacy Policy
                </a>
              </p>
            </div>
          </div>
        </div>

        {/* Right side - Background Image */}
        <div className="hidden lg:block relative flex-1">
          <div className="absolute inset-0">
            <img
              className="h-full w-full object-cover"
              src="https://images.unsplash.com/photo-1664575602276-acd073f104c1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
              alt="Modern office"
            />
            <div className="absolute inset-0 bg-indigo-900 mix-blend-multiply opacity-20"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center p-16">
            <blockquote className="relative max-w-lg">
              <div className="relative z-10">
                <p className="text-xl font-medium text-white">
                  "ISO Docs has revolutionized how we handle our quality management system. The platform's comprehensive features have made ISO certification maintenance effortless."
                </p>
                <footer className="mt-6">
                  <p className="text-base font-medium text-white">David Martinez</p>
                  <p className="text-sm text-indigo-100">Quality Assurance Director at GlobalTech</p>
                </footer>
              </div>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;