import React from 'react';
import { CreateOrganization } from '@clerk/clerk-react';
import { FileText, Users, Building2 } from 'lucide-react';

const CreateOrganizationPage = () => {
  return (
    <div className="min-h-screen bg-white">
      <div className="flex min-h-screen">
        {/* Left side - Create Organization Form */}
        <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-md w-full space-y-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-6">
                <FileText className="h-8 w-8 text-indigo-600" />
                <h1 className="text-2xl font-bold text-gray-900">ISO Docs</h1>
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Create Organization</h2>
              <p className="mt-2 text-sm text-gray-600">
                Set up a new organization to collaborate with your team
              </p>
            </div>

            <CreateOrganization
              routing="path"
              path="/create-organization"
              afterCreateOrganizationUrl="/dashboard"
              appearance={{
                elements: {
                  rootBox: "w-full",
                  card: "w-full space-y-6",
                  headerTitle: "hidden",
                  headerSubtitle: "hidden",
                  formFieldInput: "w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-sm",
                  formFieldLabel: "block text-sm font-medium text-gray-700",
                  formButtonPrimary: "w-full bg-indigo-600 text-white rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors",
                  footerAction: "text-center mt-4",
                  footerActionLink: "text-indigo-600 hover:text-indigo-500 font-medium",
                  formFieldError: "text-sm text-red-600",
                  avatarBox: "w-20 h-20 rounded-lg bg-gray-100 flex items-center justify-center text-gray-400",
                  avatarImagePlaceholder: "w-8 h-8",
                  organizationSwitcherTrigger: "w-full flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50"
                }
              }}
            />

            <div className="space-y-6 bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Users className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Team Collaboration</h3>
                  <p className="text-sm text-gray-500">Invite team members and manage permissions</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Building2 className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Multiple Organizations</h3>
                  <p className="text-sm text-gray-500">Create and switch between different organizations</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Background Image */}
        <div className="hidden lg:block relative flex-1">
          <div className="absolute inset-0">
            <img
              className="h-full w-full object-cover"
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2301&q=80"
              alt="Modern office workspace"
            />
            <div className="absolute inset-0 bg-indigo-900 mix-blend-multiply opacity-20"></div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center p-16">
            <blockquote className="relative max-w-lg">
              <div className="relative z-10">
                <p className="text-xl font-medium text-white">
                  "Creating an organization in ISO Docs was the first step in transforming our documentation process. Now our entire team collaborates seamlessly on maintaining our ISO compliance."
                </p>
                <footer className="mt-6">
                  <p className="text-base font-medium text-white">Michael Chen</p>
                  <p className="text-sm text-indigo-100">Operations Director at InnovateX</p>
                </footer>
              </div>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateOrganizationPage;