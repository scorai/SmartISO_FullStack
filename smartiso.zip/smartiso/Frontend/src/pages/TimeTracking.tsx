import React from 'react';
import { Play, Pause, Clock, Calendar, BarChart2, Plus } from 'lucide-react';

const TimeTracking = () => {
  const timeEntries = [
    {
      id: 1,
      project: 'Website Redesign',
      task: 'Design System Implementation',
      startTime: '09:00 AM',
      endTime: '11:30 AM',
      duration: '2h 30m',
      status: 'completed'
    },
    {
      id: 2,
      project: 'Mobile App',
      task: 'User Research',
      startTime: '01:00 PM',
      endTime: null,
      duration: '1h 15m',
      status: 'active'
    },
    {
      id: 3,
      project: 'Marketing Campaign',
      task: 'Content Creation',
      startTime: '03:00 PM',
      endTime: '04:30 PM',
      duration: '1h 30m',
      status: 'completed'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-semibold">Time Tracking</h1>
            <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
              <Plus className="h-5 w-5" />
              New Entry
            </button>
          </div>
          
          {/* Timer Card */}
          <div className="bg-indigo-50 p-6 rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white">
                    <option>Website Redesign</option>
                    <option>Mobile App</option>
                    <option>Marketing Campaign</option>
                  </select>
                  <select className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white">
                    <option>Design System</option>
                    <option>User Research</option>
                    <option>Development</option>
                  </select>
                </div>
                <p className="text-sm text-indigo-600">Started at 09:00 AM</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-3xl font-bold text-indigo-600">00:45:12</div>
                <button className="p-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                  <Pause className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <h3 className="font-medium">Today</h3>
            </div>
            <p className="text-2xl font-semibold">5h 15m</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-50 rounded-lg">
                <Calendar className="h-5 w-5 text-purple-600" />
              </div>
              <h3 className="font-medium">This Week</h3>
            </div>
            <p className="text-2xl font-semibold">28h 45m</p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-green-50 rounded-lg">
                <BarChart2 className="h-5 w-5 text-green-600" />
              </div>
              <h3 className="font-medium">This Month</h3>
            </div>
            <p className="text-2xl font-semibold">87h 30m</p>
          </div>
        </div>

        {/* Time Entries */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Recent Time Entries</h2>
          </div>
          <div className="divide-y divide-gray-100">
            {timeEntries.map((entry) => (
              <div key={entry.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">{entry.project}</h3>
                    <p className="text-sm text-gray-500">{entry.task}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-gray-500">
                      {entry.startTime} - {entry.endTime || 'Running'}
                    </div>
                    <div className="font-medium">{entry.duration}</div>
                    {entry.status === 'active' ? (
                      <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                        <Pause className="h-5 w-5" />
                      </button>
                    ) : (
                      <button className="p-2 text-green-600 hover:bg-green-50 rounded-lg">
                        <Play className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimeTracking;