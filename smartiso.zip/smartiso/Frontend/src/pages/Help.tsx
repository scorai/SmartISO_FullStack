import React from 'react';
import { Search, Book, FileText, MessageCircle, Phone, Mail } from 'lucide-react';

const Help = () => {
  const categories = [
    {
      title: 'Getting Started',
      icon: Book,
      articles: [
        'Quick Start Guide',
        'Setting Up Your Account',
        'Team Management',
        'Project Creation'
      ]
    },
    {
      title: 'Features & Tutorials',
      icon: FileText,
      articles: [
        'Time Tracking Basics',
        'Project Management',
        'Team Collaboration',
        'Analytics & Reports'
      ]
    },
    {
      title: 'FAQs',
      icon: MessageCircle,
      articles: [
        'Billing & Subscriptions',
        'Security & Privacy',
        'Account Settings',
        'Integrations'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="px-6 py-8">
          <h1 className="text-2xl font-semibold text-center mb-2">How can we help you?</h1>
          <p className="text-gray-500 text-center mb-6">
            Search our knowledge base or browse categories below
          </p>
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search for articles..."
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <div key={category.title} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 bg-indigo-50 rounded-lg">
                    <Icon className="h-5 w-5 text-indigo-600" />
                  </div>
                  <h2 className="text-lg font-semibold">{category.title}</h2>
                </div>
                <ul className="space-y-3">
                  {category.articles.map((article) => (
                    <li key={article}>
                      <a
                        href="#"
                        className="text-gray-600 hover:text-indigo-600 text-sm flex items-center gap-2"
                      >
                        <span className="h-1 w-1 bg-gray-300 rounded-full"></span>
                        {article}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Contact Support */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl font-semibold text-center mb-6">Still need help?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Phone className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="font-medium">Contact Support</h3>
              </div>
              <p className="text-sm text-gray-500 mb-4">
                Get in touch with our support team for personalized assistance
              </p>
              <button className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
                Contact Support
              </button>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-purple-50 rounded-lg">
                  <Mail className="h-5 w-5 text-purple-600" />
                </div>
                <h3 className="font-medium">Email Us</h3>
              </div>
              <p className="text-sm text-gray-500 mb-4">
                Send us an email and we'll get back to you within 24 hours
              </p>
              <button className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
                Send Email
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Help;