import { Outlet, useNavigate } from 'react-router-dom';
import { SignedIn, SignedOut, SignInButton, UserButton, OrganizationSwitcher } from '@clerk/clerk-react';
import { NavLink } from 'react-router-dom';
import { 
  FileText, 
  LayoutDashboard, 
  MessageSquare, 
  Settings, 
  Book,
  Calendar,
  Users,
  FolderKanban,
  HelpCircle,
  Building2
} from 'lucide-react';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', to: '/dashboard' },
  { icon: Calendar, label: 'Calendar', to: '/calendar' },
  { icon: FolderKanban, label: 'Projects', to: '/projects' },
  { icon: Book, label: 'Documentation', to: '/documentation' },
  { icon: Users, label: 'Team', to: '/team' },
  { icon: Settings, label: 'Settings', to: '/settings' },
  { icon: HelpCircle, label: 'Help Center', to: '/help' },
];

export default function Layout() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <SignedIn>
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200 flex flex-col shadow-soft-sm">
          <div className="p-4">
            <div className="flex items-center gap-2 mb-8">
              <FileText className="h-6 w-6 text-indigo-600" />
              <h1 className="text-lg font-semibold">Aerodocs</h1>
            </div>
            
            <div className="mb-6">
              <OrganizationSwitcher
                afterCreateOrganizationUrl="/dashboard"
                hidePersonal
                appearance={{
                  elements: {
                    rootBox: "w-full",
                    organizationSwitcherTrigger: "w-full flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 transition-colors button-glow"
                  }
                }}
              />
              
              <div className="space-y-1 mt-2">
                <button
                  onClick={() => navigate('/organization')}
                  className="w-full flex items-center gap-2 p-3 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 transition-colors button-glow"
                >
                  <Building2 className="h-5 w-5 text-gray-500" />
                  <span>Organization Settings</span>
                </button>
                <button
                  onClick={() => navigate('/chatbot')}
                  className="w-full flex items-center gap-2 p-3 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 transition-colors button-glow"
                >
                  <MessageSquare className="h-5 w-5 text-gray-500" />
                  <span>ISO Assistant</span>
                </button>
              </div>
            </div>
            
            <nav className="space-y-1">
              {navItems.map(({ icon: Icon, label, to }) => (
                <NavLink
                  key={to}
                  to={to}
                  className={({ isActive }) =>
                    `flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? 'bg-indigo-50 text-indigo-600 shadow-soft-sm'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`
                  }
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </NavLink>
              ))}
            </nav>
          </div>
          
          <div className="mt-auto p-4 border-t border-gray-200">
            <UserButton
              afterSignOutUrl="/"
              appearance={{
                elements: {
                  userButtonTrigger: "flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50 w-full button-glow",
                  userButtonPopoverCard: "shadow-soft-xl border border-gray-200",
                  userButtonPopoverFooter: "border-t border-gray-200"
                }
              }}
            />
          </div>
        </div>
      </SignedIn>

      <div className="flex-1 flex flex-col">
        <SignedOut>
          <header className="bg-white shadow-soft-sm">
            <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <FileText className="h-6 w-6 text-indigo-600" />
                <h1 className="text-lg font-semibold text-gray-900">Aerodocs</h1>
              </div>
              <SignInButton mode="modal">
                <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 button-glow">
                  Sign in
                </button>
              </SignInButton>
            </div>
          </header>
        </SignedOut>
        
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}