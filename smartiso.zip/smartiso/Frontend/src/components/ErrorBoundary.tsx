import React from 'react';
import { AlertCircle, RefreshCw, Globe } from 'lucide-react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  isRetrying: boolean;
  retryCount: number;
}

class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    isRetrying: false,
    retryCount: 0
  };

  private maxRetries = 3;
  private retryDelay = 1500;

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { 
      hasError: true, 
      error,
      isRetrying: false
    };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error:', error);
    console.error('Error Info:', errorInfo);
  }

  private handleRetry = async () => {
    if (this.state.retryCount >= this.maxRetries) {
      this.setState({
        error: new Error('Maximum retry attempts reached. Please try again later.'),
        isRetrying: false
      });
      return;
    }

    this.setState({ isRetrying: true });
    
    try {
      await new Promise(resolve => setTimeout(resolve, this.retryDelay));
      
      this.setState(prevState => ({
        hasError: false,
        error: null,
        isRetrying: false,
        retryCount: prevState.retryCount + 1
      }));
      
      window.location.reload();
    } catch (error) {
      this.setState({
        isRetrying: false,
        error: error instanceof Error ? error : new Error('Retry failed')
      });
    }
  };

  private getErrorMessage = (): string => {
    const error = this.state.error;
    if (!error) return 'An unexpected error occurred';

    if (error.message.includes('CORS') || error.message.includes('network')) {
      return 'Unable to connect to authentication service. Please check your internet connection and ensure you\'re using the correct environment.';
    }

    if (error.message.includes('refused')) {
      return 'Connection refused. The authentication service might be temporarily unavailable.';
    }

    return error.message;
  };

  public render() {
    if (this.state.hasError) {
      const isMaxRetries = this.state.retryCount >= this.maxRetries;

      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="flex justify-center mb-4">
                {isMaxRetries ? (
                  <Globe className="h-16 w-16 text-orange-500" />
                ) : (
                  <AlertCircle className="h-16 w-16 text-red-500" />
                )}
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Connection Error</h1>
              <p className="text-gray-600 mb-6">
                {this.getErrorMessage()}
              </p>
              {!isMaxRetries && (
                <button
                  onClick={this.handleRetry}
                  disabled={this.state.isRetrying}
                  className={`inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {this.state.isRetrying ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Retrying...
                    </>
                  ) : (
                    `Retry Connection (${this.maxRetries - this.state.retryCount} attempts remaining)`
                  )}
                </button>
              )}
              {isMaxRetries && (
                <div className="text-sm text-gray-500 mt-4">
                  Please try again later or contact support if the issue persists.
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;