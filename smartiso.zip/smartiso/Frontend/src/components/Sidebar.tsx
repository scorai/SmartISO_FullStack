import React from 'react';
import { NavLink } from 'react-router-dom';
import { FileText, LayoutDashboard, Settings, MessageSquare } from 'lucide-react';
import { UserButton } from '@clerk/clerk-react';

const Sidebar = () => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', to: '/dashboard' },
    { icon: FileText, label: 'Documents', to: '/documents' },
    { icon: MessageSquare, label: 'Chatbot', to: '/chatbot' },
    { icon: Settings, label: 'Settings', to: '/settings' },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 p-4 flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-2">
          <FileText className="h-8 w-8 text-indigo-600" />
          <h1 className="text-xl font-bold">ISO Docs</h1>
        </div>
        <UserButton afterSignOutUrl="/sign-in" />
      </div>
      
      <nav className="space-y-2">
        {navItems.map(({ icon: Icon, label, to }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-indigo-50 text-indigo-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`
            }
          >
            <Icon className="h-5 w-5" />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;