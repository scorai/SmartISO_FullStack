import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { SignedIn, SignedOut, RedirectToSignIn } from '@clerk/clerk-react';
import Layout from './components/Layout';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import Calendar from './pages/Calendar';
import Projects from './pages/Projects';
import Chatbot from './pages/Chatbot';
import Documentation from './pages/Documentation';
import Team from './pages/Team';
import Analytics from './pages/Analytics';
import TimeTracking from './pages/TimeTracking';
import Help from './pages/Help';
import Settings from './pages/Settings';
import ProfileSettings from './pages/settings/ProfileSettings';
import OrganizationSettings from './pages/settings/OrganizationSettings';
import SecuritySettings from './pages/settings/SecuritySettings';
import NotificationSettings from './pages/settings/NotificationSettings';
import EmailSettings from './pages/settings/EmailSettings';
import LanguageSettings from './pages/settings/LanguageSettings';
import SessionSettings from './pages/settings/SessionSettings';
import DangerZone from './pages/settings/DangerZone';
import CreateOrganizationPage from './pages/auth/CreateOrganization';
import OrganizationProfilePage from './pages/organization/OrganizationProfile';

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Landing Page - Only for signed out users */}
        <Route path="/" element={
          <>
            <SignedIn>
              <Navigate to="/dashboard" replace />
            </SignedIn>
            <SignedOut>
              <LandingPage />
            </SignedOut>
          </>
        } />

        {/* Protected Routes */}
        <Route element={
          <>
            <SignedIn>
              <Layout />
            </SignedIn>
            <SignedOut>
              <RedirectToSignIn />
            </SignedOut>
          </>
        }>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/documentation" element={<Documentation />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/team" element={<Team />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/time-tracking" element={<TimeTracking />} />
          <Route path="/help" element={<Help />} />

          {/* Settings Routes */}
          <Route path="/settings">
            <Route index element={<Settings />} />
            <Route path="profile" element={<ProfileSettings />} />
            <Route path="organization" element={<OrganizationSettings />} />
            <Route path="security" element={<SecuritySettings />} />
            <Route path="notifications" element={<NotificationSettings />} />
            <Route path="email" element={<EmailSettings />} />
            <Route path="language" element={<LanguageSettings />} />
            <Route path="sessions" element={<SessionSettings />} />
            <Route path="danger-zone" element={<DangerZone />} />
          </Route>

          {/* Organization Routes */}
          <Route path="/organization" element={<OrganizationProfilePage />} />
          <Route path="/create-organization" element={<CreateOrganizationPage />} />
        </Route>

        {/* Catch all redirect */}
        <Route path="*" element={
          <>
            <SignedIn>
              <Navigate to="/dashboard" replace />
            </SignedIn>
            <SignedOut>
              <Navigate to="/" replace />
            </SignedOut>
          </>
        } />
      </Routes>
    </Router>
  );
}