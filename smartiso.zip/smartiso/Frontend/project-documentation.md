# ISO Documentation System Project

## Project Overview
This project appears to be a web application for ISO documentation management. It's built with React, TypeScript, and uses Supabase as the backend database. The application allows organizations to manage ISO-related documents, their versions, and related questionnaire responses.

## Project Structure

### Root Directory
- **package.json**: Contains project dependencies and scripts
- **tsconfig.json**, **tsconfig.app.json**, **tsconfig.node.json**: TypeScript configuration files
- **vite.config.ts**: Configuration for the Vite build tool
- **tailwind.config.js**: Configuration for TailwindCSS styling
- **postcss.config.js**: PostCSS configuration for processing CSS
- **eslint.config.js**: ESLint configuration for code linting
- **index.html**: Main HTML entry point

### Source Code (/src)
- **main.tsx**: Application entry point
- **App.tsx**: Main application component
- **index.css**: Global CSS styles
- **/components**: UI components used throughout the application
- **/lib**: Utility functions and shared code
- **/pages**: Page components for different routes

### Database (/supabase)
- **/migrations**: SQL migrations for setting up and updating the database schema

## Database Schema

The database schema (defined in `/supabase/migrations/20250314012017_super_forest.sql`) consists of:

1. **organizations**: Stores basic organization information and settings
   - Fields: id, name, industry, size, website, created_at, updated_at, settings

2. **folders**: Manages document organization structure
   - Fields: id, organization_id, name, parent_id, created_at, updated_at
   - Organizations have default folders: Quality Manual, Procedures, Work Instructions, Records

3. **documents**: Stores document content and metadata
   - Fields: id, organization_id, folder_id, title, type, content, status, created_by, created_at, updated_at, last_edited_by, version, metadata

4. **document_versions**: Maintains version history for documents
   - Fields: id, document_id, version, content, created_by, created_at, comment

5. **questionnaire_responses**: Stores user responses for document generation
   - Fields: id, document_id, responses, created_by, created_at, updated_at

## Security Features
- Row Level Security (RLS) enabled on all tables
- Organization-based access policies
- Role-based permissions (editors vs. viewers)
- Data isolation between organizations

## Key Functionality
- Document management with versioning
- Hierarchical folder organization
- Questionnaire-based document generation
- Organization-specific content isolation
- User role management for access control

## Development Setup
1. Install dependencies: `npm install`
2. Start development server: `npm run dev`
3. Build for production: `npm run build`
4. Preview production build: `npm run preview`

## Technologies Used
- React 18
- TypeScript
- Vite
- TailwindCSS
- Clerk (for authentication)
- Supabase (for database)
- Various UI libraries (Radix UI, Headless UI) 