# ISO Documentation System

A comprehensive web application for managing ISO documentation, built with React, TypeScript, and Supabase.

## Overview

This application helps organizations create, manage, and maintain ISO-compliant documentation with features like document versioning, hierarchical organization, and access control. It's designed for companies implementing ISO standards that need to maintain quality management documentation.

## Features

- **Document Management**: Create, edit, and manage ISO-compliant documents
- **Version Control**: Track document changes with full version history
- **Hierarchical Organization**: Organize documents in a folder structure
- **Access Control**: Organization-based isolation with role-based permissions
- **Questionnaire-Based Generation**: Generate document templates from user responses
- **Modern UI**: Clean, responsive interface built with modern React components

## Tech Stack

### Frontend
- React 18.2.0
- TypeScript 5.2.2
- Vite 5.1.6 (build tool)
- TailwindCSS 3.4.1 (styling)
- React Router 6.22.2 (routing)
- Clerk Authentication (user management)
- UI Components:
  - Radix UI (accessible components)
  - Headless UI (unstyled components)
  - Framer Motion (animations)
  - Recharts (data visualization)

### Backend
- Supabase (PostgreSQL database with serverless functions)
- Row Level Security (RLS) for data protection
- SQL migrations for database schema management

## Database Schema

The application uses a PostgreSQL database with the following key tables:

1. **organizations**: Organization details and settings
2. **folders**: Document organization hierarchy
3. **documents**: Document content and metadata
4. **document_versions**: Version history for documents
5. **questionnaire_responses**: User input for document generation

Security is implemented via Row Level Security policies ensuring data isolation between organizations and proper role-based access.

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Supabase account (for database)
- Clerk account (for authentication)

### Installation

1. Clone the repository:
   ```bash
   git clone [repository-url]
   cd iso-documentation-system
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file with your API keys:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_key
   VITE_CLERK_PUBLISHABLE_KEY=your_clerk_key
   ```

4. Set up the database:
   ```bash
   npx supabase db push
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```

### Building for Production

```bash
npm run build
```

The build artifacts will be stored in the `dist/` directory.

## Project Structure

```
iso-documentation-system/
├── src/                      # Source code
│   ├── components/           # Reusable UI components
│   ├── lib/                  # Utilities and helpers
│   ├── pages/                # Page components
│   ├── App.tsx               # Main application component
│   └── main.tsx              # Application entry point
├── supabase/                 # Supabase configuration
│   └── migrations/           # Database migrations
├── public/                   # Static assets
├── index.html                # HTML entry point
├── package.json              # Project dependencies
├── tsconfig.json             # TypeScript configuration
└── vite.config.ts            # Vite configuration
```

## Key Components

### Authentication
The application uses Clerk for authentication and user management. Users are associated with organizations, and access control is managed through database policies.

### Document Editor
The document editor supports structured content with sections, tables, and formatting options specifically designed for ISO documentation.

### Version Control
Each document edit creates a new version, allowing users to track changes, revert to previous versions, and maintain an audit trail.

### Organization Management
Organizations are isolated from each other, with specific roles (admin, editor, viewer) controlling access to documents.

## Development Workflow

1. **Setup**: Initialize the project structure, set up Supabase and Clerk
2. **Authentication**: Implement user authentication and registration
3. **Database**: Define and create database schema
4. **UI Components**: Build reusable UI components for the application
5. **Core Features**: Implement document management, versioning, and folder structure
6. **Access Control**: Set up organization isolation and role-based permissions
7. **Deployment**: Deploy the application to a hosting provider

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -am 'Add feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

For questions or support, please contact [your-email@example.com]. 